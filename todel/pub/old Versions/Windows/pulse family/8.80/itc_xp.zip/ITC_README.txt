InstruTECH Corporation
20 Vanderventer Avenue
Suite 101E
Port Washington, New York 11050
Tel: (516) 883-1300
Fax:(516) 883-1558
email: support@instrutech.com
web: http://www.instrutech.com

The ITC Windows installer package supports all InstruTECH data acquisition hardware, including the interfaces installed in the Heka elektronik EPC 9, EPC-10/x and EPC 10Plus amplifiers.  The setup program will also install the utility programs ITC_Control and ITCDemoG. 

For Windows 98, ME, Windows 2000 and Windows XP (PCI and USB):

These operating systems use the "Device Manager" for installing the driver files.  Before installing the hardware in your system extract the driver files to a temporary directory of your choice.  When the operating system detects the new device browse to the directory where the driver files are located.  Once the InstruTECH.inf file is read the appropriate files will be installed.  When installation is completed you will be prompted to reboot the system.  If the utility demo files are to be installed then you can reboot after the setup program completes.  Please see instructions below for installing these demo files.

For Windows 98, ME (ISA host) or Windows NT (ISA and PCI):

1- After installing the hardware in your system extract the driver files to a temporary directory of your choice.
2- Go to the directory where the driver files are located and run the Setup.exe file.
3- Select the appropriate host interface for your device, ITCxx ISA, ITCxx PCI or DVP32 (PCI only).  Select Next to continue.
4- If you would like to install the ITC utility program leave the checkbox "ITC Demo Program" selected otherwise un-select it.  Select Next to continue.
5- Select the location to install the demo programs, the default location is "c:\program files\Instrutech".  Select Next to continue.
6- Select the program group to install the demo program shortcuts to, the default group is "Instrutech".  Select Next to continue.
7- When completed you will be prompted to reboot the system.  Please note that the system must be rebooted for the drivers to load.

Please note that ISA host interfaces are only supported in Windows 98 and Windows NT.

ITC Demo programs:

The program ITCDemoG and ITC_Control can be used to verify the driver installation and the hardware.

ITCDemoG:

The ITCDemoG program will initialize the selected device, start acquisition and continuously display the result.  DAC output 0 will send out an increasing amplitude sine wave that can be read back on ADC input 0.
  
1- Before running the program please connect a BNC cable between DAC 0 and ADC 0.
2- Execute ITCDemoG from the program group Instrutech.
3- Select the device to test.  Please note that for an ITC-18 with a USB-18 host the device USB-18 must be selected.  For an ITC-16 with a USB-16 host the device USB-16 must be selected.
4- If more than one of the same device type is installed the device can be selected by choosing the appropriate "Device Number".  For most users the default of 0 will be used.
5- Once "Next" is selected the program will initialize the device and start the acquisition.  If the increasing sine wave is displayed then the connections and driver installation are all working.
6- The acquisition can be stopped by selecting "Stop" from the Controls pull down menu.

ITC_Control:

The ITC_Control program is a more extensive acquisition test utility.  The program supports all of our ITC interfaces and allows you to use all of the analog and digital channels for that device.

1- Execute ITC_Control from the program group Instrutech.
2- The program will search your system for all InstruTECH devices.  A device tree will be created that lists all of the attached devices.
3- If more than one device is listed select the device to test.  Please note that for an ITC-18 with a USB-18 host the device USB-18 must be selected.  For an ITC-16 with a USB-16 host the device USB-16 must be selected.  Once the device is selected the properties for the device are displayed.  Some devices have serial numbers written to their internal firmware and they will also be displayed.
4- There are 3 main sections to this program:
	1- To re-initialize a device select the green "led" button or go to "Re-Initialize" in the "File" pull down menu.
	2- To go to the I/O control window select the I/O icon or go to "IO Control" in the "File" pull down menu.
	3- To go to the Graph window select the graph icon or go to "Graph" in the "File" pull down menu.

The I/O control window can be used to perform static tests on any of the input and output channels including digital I/O.  When an output is selected with either a key or mouse command a single read on all of the inputs will be performed as well.  For example if a BNC cable was connected between DAC 0 and ADC 0.  When a new value is entered in the DAC 0 field as soon as the return key is hit ADC 0 would also be updated with the read value.  To continuously read the inputs select the "read" button.

The Graph window can be used to send out and read data waves on any or all selected channels.  The channel tree will display all of the available channels for the selected device.  As a ADC or DAC channel is selected the parameters for that channel are displayed.  For example if ADC 0 is selected the parameters for that channel are displayed and can be changed (i.e. trace color, sampling rate, overflow flags, etc).  The same is true when a DAC output channels is selected.  Once the channels and parameters are specified then acquisition can be started by selecting "Start".  The "Start" button will be renamed to "Stop" and can now be used to stop the acquisition.

Source for these programs can be made available for developers who would like to support our interfaces.